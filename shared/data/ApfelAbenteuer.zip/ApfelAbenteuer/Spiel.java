import java.util.ArrayList;
/**
 * Write a description of class Spiel here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Spiel extends Ereignisbehandlung {

    private Korb korb;
    private Boden boden;
    private Text gameOver;

    private int äpfelAmBoden;
    private ArrayList<Apfel> äpfel;

    public Spiel() {
        super();

        Rechteck r = new Rechteck();
        r.PositionSetzen(10, 10);
        r.GrößeSetzen(710, 510);
        r.FarbeSetzen("cyan");
        r.GanzNachHintenBringen();

        boden = new Boden();
        korb = new Korb();

        äpfel = new ArrayList<Apfel>();
        äpfelAmBoden = 0;

        TaktdauerSetzen(50);
    }

    @Override void TaktImpulsAusführen() {

        if (äpfelAmBoden < 3) {

            /*
             * Äpfel werden nur hinzugefügt wenn eine Zufallszahl zwischen 0 und 35 gleich 5 ist,
             * damit nicht zu viele Äpfel auf einmal hinzugefügt werden
             */
            if (zufallszahl(0, 35) == 5) {
                äpfel.add(new Apfel(zufallszahl(30, 690)));
            }

            for (Apfel apfel : äpfel) {
                
                /*
                 * Wenn der Apfel höher als der Boden ist, dann soll er fallen,
                 * ansonsten soll er sich nicht bewegen
                 * 
                 * Wenn ein Apfel am Boden aufkommt, dann wird zu äpfelAmBoden 1 hinzugefügt 
                 * Damit das für jeden Apfel nur einmal passiert, wird vorher überprüft, ob der Apfel schon am Boden ist
                 */
                if (apfel.yGeben() < 490) {
                    apfel.fallen();
                } else if (apfel.amBodenGeben() == "falsch" && apfel.entferntGeben() == "falsch") {
                    äpfelAmBoden++;  
                    apfel.amBodenSetzen("wahr");
                }

                /* 
                 * Wenn der Apfel vom Korb berührt wird, dann wird er entfernt
                 */
                if (apfel.xGeben() > korb.xGeben() - 40 && apfel.xGeben() < korb.xGeben() + 100 && apfel.yGeben() > 280 && apfel.yGeben() < 350) {
                    apfel.entfernen();
                }

            }

        } else {
            /*
             * Wenn mehr als 3 Äpfel am Boden liegen, dann wir GameOver angezeigt
             */
            gameOver = new Text();
            gameOver.TextSetzen("Game Over!");
            gameOver.PositionSetzen(300, 510/2);
            gameOver.TextGrößeSetzen(25);
        }

    }

    @Override void SonderTasteGedrückt (int taste)
    {
        if (äpfelAmBoden < 3) {
            switch(taste)
            {
                case 37: korb.linksBewegen();
                    break;
                case 39: korb.rechtsBewegen();
                    break;
                default: break;
            }
        }
    }  

    private int zufallszahl(int min, int max) {
        return (int) (min + Math.random() * (max - min));
    }
}
