
/**
 * Write a description of class Boden here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Boden
{
    
    private Rechteck rechteck; 
    
    public Boden() {
        
        rechteck = new Rechteck();
        rechteck.PositionSetzen(10, 500);
        rechteck.GrößeSetzen(710, 20);
        rechteck.FarbeSetzen("grün");
        
    }
    
}
