
/**
 * Write a description of class Apfel here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Apfel
{
   private Kreis kreis;
   private String amBoden;
   private String istEntfernt;
   
   public Apfel(int x) {
       kreis = new Kreis();
       kreis.FarbeSetzen("rot");
       kreis.RadiusSetzen(20);
       
       kreis.PositionSetzen(x, -20);
       
       amBoden = "falsch";
       istEntfernt = "falsch";
   }
   
   String entferntGeben() {
       return istEntfernt;
   }
   
   /*
    * Wenn der Apfel am boden aufgekommen ist, dann wird er entfernt
    * Das passiert durch die methode entfernen 
    */
   void entfernen() {
       kreis.Entfernen();
       istEntfernt = "wahr";
   }
   
   void fallen() {
       kreis.Verschieben(0, 6);
   }
   
   int yGeben() {
       return kreis.y;
   }
   
   int xGeben() {
       return kreis.x;
   }
   
   String amBodenGeben() {
       return amBoden;
   }
   
   void amBodenSetzen(String s) {
        amBoden = s;
   }
   
}
