
/**
 * Write a description of class Korb here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Korb
{

    private Rechteck rechteck;

    public Korb() {
        rechteck = new Rechteck();
        rechteck.FarbeSetzen("braun");
        rechteck.GrößeSetzen(100, 20);
        rechteck.PositionSetzen(710/2 - 80/2, 300);

    }

    void linksBewegen() {
        if (rechteck.x > 15) {
            rechteck.Verschieben(-25, 0);
        }
    }

    void rechtsBewegen() {
        if (rechteck.x < 615) {
            rechteck.Verschieben(25, 0);
        }
    }
    
    int xGeben() {
        return rechteck.x;
    }

     int yGeben() {
        return rechteck.y;
    }

}
